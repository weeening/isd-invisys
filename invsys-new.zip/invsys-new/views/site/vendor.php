<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\bootstrap\ActiveForm;
use yii\grid\ActionColumn;

$this->title = 'Vendor List';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
	
	<?= GridView::widget([
		'dataProvider' => $dataProvider, 
		'columns' => [
			'ven_id',
			'ven_name',
			'ven_phone',
			'ven_email',
			'ven_address',
			[
				'class' => ActionColumn::className(),
				'template' => '{delete}',
				'buttons' => [
					'delete' => function ($url, $model) {
						return Html::a('<span class="glyphicon glyphicon-trash"></span>', ['/site/delete-vendor', 'id' => $model->ven_id]);
					}
				],
			]
			
		]
	]) ?>
	
	<?php if (Yii::$app->user->can("admin")): ?>
		
		 <div class="row">
            <div class="col-lg-5">

                <?php $form = ActiveForm::begin(); ?>

                    <?= $form->field($model, 'ven_id')?>
					<?= $form->field($model, 'ven_name')?>
					<?= $form->field($model, 'ven_phone')?>
					<?= $form->field($model, 'ven_email')?>
					<?= $form->field($model, 'ven_address')?>


                    <div class="form-group">
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>
	<?php endif; ?>
</div>
