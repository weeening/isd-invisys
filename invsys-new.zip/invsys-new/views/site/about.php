<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\bootstrap\ActiveForm;
use yii\grid\ActionColumn;

$this->title = 'Stationery List';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
	
	<?= GridView::widget([
		'dataProvider' => $dataProvider, 
		'columns' => [
			'sta_id',
			'sta_name',
			'sta_brand',
			[
				'attribute' => 'sta_price',
				'format' => 'decimal',
			],
			'sta_category',
			'sta_quantity',
			//'ven.ven_name', (alternative way)
			[
				'attribute' => 'ven.ven_name',
				'visible' => Yii::$app->user->can("admin"),
			],
			/*[
				'label' => 'Your Head',
				'value' => function ($model) {
					return $model->ven->ven_name. " - ".$model->ven->ven_id;
				},
				'visible' => Yii::$app->user->can("admin"),
				
			],
			*/
			
			[
				'visible' => Yii::$app->user->can("admin"),
				'class' => ActionColumn::className(),
				'template' => '{delete}',
				'buttons' => [
					'delete' => function ($url, $model) {
						return Html::a('<span class="glyphicon glyphicon-trash"></span>', ['/site/delete-stationery', 'id' => $model->sta_id]);
					}
				
				],
			]
		]
	]) ?>
	
	<?php if (Yii::$app->user->can("admin")): ?>
		
		 <div class="row">
            <div class="col-lg-5">

                <?php $form = ActiveForm::begin(); ?>

                    <?= $form->field($model, 'sta_id')?>
					<?= $form->field($model, 'sta_name')?>
					<?= $form->field($model, 'sta_brand')?>
					<?= $form->field($model, 'sta_price')?>
					<?= $form->field($model, 'sta_category')?>
					<?= $form->field($model, 'sta_quantity')?>
					<?= $form->field($model, 'ven_id')->dropDownList(ArrayHelper::map($venlist, 'ven_id','ven_name'), ['prompt' => 'Please select the vendor']) ?>


                    <div class="form-group">
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
	<?php endif; ?>
</div>
</div>
