<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\bootstrap\ActiveForm;
use yii\grid\ActionColumn;

$this->title = 'Orders List';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
	
	<?= GridView::widget([
		'dataProvider' => $dataProvider, 
		'columns' => [
			'order_id',
			'ven.ven_name',
			'sta.sta_name',
			'order_quantity',
			'order_date',
			[
				'class' => ActionColumn::className(),
				'template' => '{delete}',
				'buttons' => [
					'delete' => function ($url, $model) {
						return Html::a('<span class="glyphicon glyphicon-trash"></span>', ['/site/delete-order', 'id' => $model->order_id]);
					}
				],
			]
		]
	]) ?>
	
	<?php if (Yii::$app->user->can("admin")): ?>
		
		 <div class="row">
            <div class="col-lg-5">

                <?php $form = ActiveForm::begin(); ?>

                    <?= $form->field($model, 'order_id')?>
					<?= $form->field($model, 'ven_id')->dropDownList(ArrayHelper::map($venlist, 'ven_id','ven_name'), ['prompt' => 'Please select the vendor']) ?>
					<?= $form->field($model, 'sta_id')->dropDownList(ArrayHelper::map($stationerylist, 'sta_id','sta_name'), ['prompt' => 'Please select the stationery']) ?>
					<?= $form->field($model, 'order_quantity')?>


                    <div class="form-group">
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>
	<?php endif; ?>
</div>
