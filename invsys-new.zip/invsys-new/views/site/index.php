<?php

/* @var $this yii\web\View */

$this->title = 'Invisys';
?>
<div class="site-index">

    <div class="jumbotron" style="padding:0px">
        <h1>Invisys</h1>

       <!-- <p class="lead"></p> -->

    </div>

    <div class="body-content">

        <div class="row">
            <div class = "col-sm-6 col-sm-offset-3"><img class="img-responsive center-block" src="img/stationery.jpg" alt="stationery">
			<p>This is a stationery inventory system which we have created for our assignment 
			for TSD2241 Information Systems Development under Dr. Afizan Azman.</p>
            </div>
        </div>

    </div>
</div>
