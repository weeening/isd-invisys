<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Reserve;
use app\models\Stationery;
use app\models\Vendor;
use app\models\Orders;
use app\models\Users;
use yii\data\ActiveDataProvider;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

	//reserve action
	
	public function actionReserve()
    {
		$model = new Reserve();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('contactFormSubmitted');
			$model->res_id=microtime(); //setting the instances to be loaded into the database
			$model->user_id=Yii::$app->user->identity->user_id;
			$model->res_date=date("Y-m-d");
			$model->save();
            return $this->refresh();
        }
		$provider = new ActiveDataProvider([
			'query' => Reserve::find(),
		]);
		
		$query = Stationery::find(); //returns active query 
		$stationerylist = $query->all(); //list or array of stationery
        return $this->render('reserve',[
			'model'=>$model,
			'stationerylist'=>$stationerylist,
			'dataProvider' => $provider //entire list pass into the view for reserve 
		]); //pass parameter
		
		
    }
	
    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionStationerylist()
    {
		$model = new Stationery();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('contactFormSubmitted');
			$model->save();
            return $this->refresh();
        }
		$provider = new ActiveDataProvider([
			'query' => Stationery::find(),
		]);
		
		$query = Vendor::find(); //returns active query 
		$venlist = $query->all(); //list or array of vendor
		
        return $this->render('about',[
			'venlist' => $venlist,
			'dataProvider' => $provider,
			'model' => $model,
		]);
    }
	
	public function actionUserlist()
    {
		$model = new Users();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('contactFormSubmitted');
			if ($model->save()) {
				$staff = Yii::$app->authManager->getRole("staff");
				Yii::$app->authManager->assign($staff, $model->user_id);
			}
            return $this->refresh();
        }
		$provider = new ActiveDataProvider([
			'query' => Users::find(),
		]);
		
        return $this->render('users',[
			'dataProvider' => $provider,
			'model' => $model
		]);
    }
	
	public function actionVendorlist()
    {
		$model = new Vendor();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('contactFormSubmitted');
			$model->save();
            return $this->refresh();
        }
		$provider = new ActiveDataProvider([
			'query' => Vendor::find(),
		]);
		
        return $this->render('Vendor',[
			'dataProvider' => $provider,
			'model' => $model
		]);
    }
	
	public function actionOrderlist()
    {
		$model = new Orders();
        if ($model->load(Yii::$app->request->post())) {
            Yii::$app->session->setFlash('contactFormSubmitted');
			$model->order_date=date("Y-m-d");
			$model->save();
            return $this->refresh();
        }
		$provider = new ActiveDataProvider([
			'query' => Orders::find(),
		]);
		
		$query = Vendor::find(); //returns active query 
		$venlist = $query->all(); //list or array of stationery
		
		$query = Stationery::find(); //returns active query 
		$stationerylist = $query->all(); //list or array of stationery
		
        return $this->render('Orders',[
			'dataProvider' => $provider,
			'venlist' => $venlist, 
			'stationerylist' => $stationerylist,
			'model' => $model
		]);
    }
	
	public function actionDeleteOrder($id)
	{
		$model = Orders::findOne($id);
		if ($model) {
			$model->delete();
		}
		return $this->redirect(['/site/orderlist']);
	}
	
	public function actionDeleteVendor($id)
	{
		$model = Vendor::findOne($id);
		if ($model) {
			$model->delete();
		}
		return $this->redirect(['/site/vendorlist']);
	}
	
	public function actionDeleteStationery($id)
	{
		$model = Stationery::findOne($id);
		if ($model) {
			$model->delete();
		}
		return $this->redirect(['/site/stationerylist']);
	}
	
	public function actionDeleteUser($id)
	{
		$model = Users::findOne($id);
		if ($model) {
			$model->delete();
		}
		return $this->redirect(['/site/userlist']);
	}
	
}
