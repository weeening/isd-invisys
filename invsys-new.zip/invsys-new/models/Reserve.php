<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "reserve".
 *
 * @property string $res_id
 * @property string $user_id
 * @property string $sta_id
 * @property integer $res_quantity
 * @property string $res_date
 *
 * @property Users $user
 * @property Stationery $sta
 */
class Reserve extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'reserve';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['res_id'], 'required'],
            [['res_quantity'], 'integer'],
            [['res_date'], 'safe'],
            [['res_id', 'user_id', 'sta_id'], 'string', 'max' => 100],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'user_id']],
            [['sta_id'], 'exist', 'skipOnError' => true, 'targetClass' => Stationery::className(), 'targetAttribute' => ['sta_id' => 'sta_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'res_id' => 'Res ID',
            'user_id' => 'User ID',
            'sta_id' => 'Stationery ID',
            'res_quantity' => 'Quantity Reserved',
            'res_date' => 'Date Reserved',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSta()
    {
        return $this->hasOne(Stationery::className(), ['sta_id' => 'sta_id']);
    }
}
