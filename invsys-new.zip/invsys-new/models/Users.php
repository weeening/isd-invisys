<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "users".
 *
 * @property string $user_id
 * @property string $user_password
 * @property string $user_name
 * @property string $user_email
 * @property string $user_phone
 *
 * @property Reserve[] $reserves
 */
class Users extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'users';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'user_password'], 'required'],
            [['user_id', 'user_password', 'user_name', 'user_email'], 'string', 'max' => 100],
            [['user_phone'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'user_id' => 'User ID',
            'user_password' => 'User Password',
            'user_name' => 'Name',
            'user_email' => 'Email',
            'user_phone' => 'Contact Number',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReserves()
    {
        return $this->hasMany(Reserve::className(), ['user_id' => 'user_id']);
    }
	
	/**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        $query = Users::find(); //returns active query 
		$query->andWhere(['user_id'=> $id]);
		$user = $query->one(); //users instance
		
		return $user;
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
       
        return null;
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        $query = Users::find(); //returns active query 
		$query->andWhere(['user_id'=> $username]);
		$user = $query->one(); //users instance
		
		return $user;
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->user_id;
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return false;
    }

}

