<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "stationery".
 *
 * @property string $sta_id
 * @property string $sta_name
 * @property string $sta_brand
 * @property double $sta_price
 * @property string $sta_category
 * @property integer $sta_quantity
 * @property string $ven_id
 *
 * @property Orders[] $orders
 * @property Reserve[] $reserves
 * @property Vendor $ven
 */
class Stationery extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'stationery';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sta_id', 'sta_name', 'sta_brand'], 'required'],
            [['sta_price'], 'number'],
            [['sta_quantity'], 'integer'],
            [['sta_id', 'sta_name', 'sta_brand', 'sta_category', 'ven_id'], 'string', 'max' => 100],
            [['ven_id'], 'exist', 'skipOnError' => true, 'targetClass' => Vendor::className(), 'targetAttribute' => ['ven_id' => 'ven_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'sta_id' => 'Stationery ID',
            'sta_name' => 'Name',
            'sta_brand' => 'Brand',
            'sta_price' => 'Price',
            'sta_category' => 'Category',
            'sta_quantity' => 'Quantity In Stock',
            'ven_id' => 'Vendor ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Orders::className(), ['sta_id' => 'sta_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReserves()
    {
        return $this->hasMany(Reserve::className(), ['sta_id' => 'sta_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVen()
    {
        return $this->hasOne(Vendor::className(), ['ven_id' => 'ven_id']);
    }
}
