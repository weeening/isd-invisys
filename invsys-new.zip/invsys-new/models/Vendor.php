<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "vendor".
 *
 * @property string $ven_id
 * @property string $ven_name
 * @property string $ven_phone
 * @property string $ven_email
 * @property string $ven_address
 *
 * @property Orders[] $orders
 * @property Stationery[] $stationeries
 */
class Vendor extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'vendor';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ven_id', 'ven_name'], 'required'],
            [['ven_id', 'ven_name', 'ven_email', 'ven_address'], 'string', 'max' => 100],
            [['ven_phone'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ven_id' => 'Vendor ID',
            'ven_name' => 'Vendor Name',
            'ven_phone' => 'Contact Number',
            'ven_email' => 'Email',
            'ven_address' => 'Address',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrders()
    {
        return $this->hasMany(Orders::className(), ['ven_id' => 'ven_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStationeries()
    {
        return $this->hasMany(Stationery::className(), ['ven_id' => 'ven_id']);
    }
}
