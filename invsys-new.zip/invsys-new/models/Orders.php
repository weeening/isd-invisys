<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "orders".
 *
 * @property string $order_id
 * @property string $ven_id
 * @property string $sta_id
 * @property integer $order_quantity
 * @property string $order_date
 *
 * @property Stationery $sta
 * @property Vendor $ven
 */
class Orders extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'orders';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['order_id', 'ven_id', 'sta_id'], 'required'],
            [['order_quantity'], 'integer'],
            [['order_date'], 'safe'],
            [['order_id', 'ven_id', 'sta_id'], 'string', 'max' => 100],
            [['sta_id'], 'exist', 'skipOnError' => true, 'targetClass' => Stationery::className(), 'targetAttribute' => ['sta_id' => 'sta_id']],
            [['ven_id'], 'exist', 'skipOnError' => true, 'targetClass' => Vendor::className(), 'targetAttribute' => ['ven_id' => 'ven_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'order_id' => 'Order ID',
            'ven_id' => 'Vendor',
            'sta_id' => 'Stationery',
            'order_quantity' => 'Order Quantity',
            'order_date' => 'Order Date',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSta()
    {
        return $this->hasOne(Stationery::className(), ['sta_id' => 'sta_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVen()
    {
        return $this->hasOne(Vendor::className(), ['ven_id' => 'ven_id']);
    }
}
